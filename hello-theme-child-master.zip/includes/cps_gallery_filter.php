<?php
function cps_gallery_filter() {
    // Check if category_id is set and is a valid integer
    $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : 0;
    $paged = isset($_POST['paged']) ? intval($_POST['paged']) : 1;
    $posts_per_page = 21;
    
    // Prepare query arguments
    $args = array(
        'post_type' => 'image-gallery',
        'posts_per_page' => $posts_per_page,
        'paged' => $paged,
        'order' => 'ASC',
    );

    // If category_id is set and not zero, add tax_query
    if ($category_id > 0) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'cps_gallery_category',
                'field' => 'term_id',
                'terms' => $category_id,
            ),
        );
    }

    // Execute the query
    $gallery_query = new WP_Query($args);

    if ($gallery_query->have_posts()) {
        echo '<div class="gallery-content-wrapper">'; // Start of content wrapper
        while ($gallery_query->have_posts()) {
            $gallery_query->the_post();
            // Get categories for the current post
            $terms = get_the_terms(get_the_ID(), 'cps_gallery_category');
            $term_classes = '';
            if ($terms && !is_wp_error($terms)) {
                foreach ($terms as $term) {
                    $term_classes .= ' cat-' . $term->term_id;
                }
            }

            // Get the redirect URL
            $redirect_url = get_post_meta(get_the_ID(), '_redirect_url', true);

            // Output your gallery items here
            echo '<div class="gallery-item' . esc_attr($term_classes) . '">';
            if (in_array('cat-11', explode(' ', $term_classes))) {
                echo '<a href="' . esc_url($redirect_url) . '" class="gallery-link" target="_blank">';
            } else {
                echo '<a href="' . get_the_post_thumbnail_url(get_the_ID(), 'large') . '" data-lightbox="gallery" class="gallery-link">';
            }
            echo get_the_post_thumbnail(get_the_ID(), 'full');
            echo '</a>';
            echo '</div>';
        }
        echo '</div>'; // End of content wrapper

        // Pagination
        $total_pages = $gallery_query->max_num_pages;
        if ($total_pages > 1) {
            $current_page = max(1, $paged);
            $pagination_links = paginate_links(
                array(
                    'base' => '%_%',
                    'format' => '?paged=%#%',
                    'current' => $current_page,
                    'total' => $total_pages,
                    'prev_text' => __(''),
                    'next_text' => __(''),
                    'type' => 'array',
                )
            );

            echo '<div class="pagination-wrapper">'; // Start of pagination wrapper
            echo '<div class="pagination">';
            foreach ($pagination_links as $link) {
                echo $link;
            }
            echo '</div>';
            echo '</div>'; // End of pagination wrapper
        }
    } else {
        echo '<p>No gallery items found.</p>';
    }

    wp_reset_postdata();
    wp_die(); // this is required to terminate immediately and return a proper response
}
add_action('wp_ajax_nopriv_cps_gallery_filter', 'cps_gallery_filter');
add_action('wp_ajax_cps_gallery_filter', 'cps_gallery_filter');


function cps_gallery_shortcode() {
    // Fetch all gallery categories
    $categories = get_terms(
        array(
            'taxonomy' => 'cps_gallery_category',
            'hide_empty' => true,
        )
    );

    // Check if there are categories
    if (empty($categories)) {
        return '<p>No categories found.</p>';
    }

    // Get the ID of the first category
    $first_category_id = $categories[0]->term_id;

    ob_start();
    ?>
    <div class="filter-gallery-nav">
        <ul>
            <?php
            foreach ($categories as $cat) {
                ?>
                <li data-gallery-cat-id="<?php echo $cat->term_id; ?>" class="<?php echo ($cat->term_id === $first_category_id) ? 'nav-active' : ''; ?>"><?php echo $cat->name; ?></li>
                <?php
            }
            ?>
        </ul>
    </div>

    <div id="gallery-container" class="filter-gallery-item-container">
        <?php
        // Initial gallery items for the first category
        $args = array(
            'post_type' => 'image-gallery',
            'posts_per_page' => 21,
            'paged' => 1,
            'order' => 'ASC',
            'tax_query' => array(
                array(
                    'taxonomy' => 'cps_gallery_category',
                    'field' => 'term_id',
                    'terms' => $first_category_id,
                ),
            ),
        );

        $gallery_query = new WP_Query($args);

        if ($gallery_query->have_posts()) {
            echo '<div class="gallery-content-wrapper">';
            while ($gallery_query->have_posts()) {
                $gallery_query->the_post();
                // Get categories for the current post
                $terms = get_the_terms(get_the_ID(), 'cps_gallery_category');
                $term_classes = '';
                if ($terms && !is_wp_error($terms)) {
                    foreach ($terms as $term) {
                        $term_classes .= ' cat-' . $term->term_id;
                    }
                }

                // Get the redirect URL
                $redirect_url = get_post_meta(get_the_ID(), '_redirect_url', true);

                // Output gallery items
                echo '<div class="gallery-item' . esc_attr($term_classes) . '">';
                if (in_array('cat-11', explode(' ', $term_classes))) {
                    echo '<a href="' . esc_url($redirect_url) . '" class="gallery-link" target="_blank">';
                } else {
                    echo '<a href="' . get_the_post_thumbnail_url(get_the_ID(), 'large') . '" data-lightbox="gallery" class="gallery-link">';
                }
                echo get_the_post_thumbnail(get_the_ID(), 'full');
                echo '</a>';
                echo '</div>';
            }
            echo '</div>';

            // Pagination
            $total_pages = $gallery_query->max_num_pages;
            if ($total_pages > 1) {
                $current_page = max(1, 1);
                $pagination_links = paginate_links(
                    array(
                        'base' => '%_%',
                        'format' => '?paged=%#%',
                        'current' => $current_page,
                        'total' => $total_pages,
						'prev_text' => __(''),
                        'next_text' => __(''),
                        'type' => 'array',
                    )
                );
                echo '<div class="pagination-wrapper">';
                echo '<div class="pagination">';
                foreach ($pagination_links as $link) {
                    echo $link;
                }
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo '<p>No gallery items found.</p>';
        }

        wp_reset_postdata();
        ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('cps_gallery', 'cps_gallery_shortcode');
