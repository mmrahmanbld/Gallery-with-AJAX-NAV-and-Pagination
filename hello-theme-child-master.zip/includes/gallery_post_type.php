<?php
function gallery_post_type_add()
{
    $labels = array(
        'name' => __('Gallery', 'image-gallery'),
        'singular_name' => __('Gallery', 'image-gallery'),
        'add_new' => __('New Gallery Item', 'image-gallery'),
        'add_new_item' => __('Add New Gallery Item', 'image-gallery'),
        'edit_item' => __('Edit Gallery Item', 'image-gallery'),
        'new_item' => __('New Gallery Item', 'image-gallery'),
        'search_items' => __('Search Gallery Item', 'image-gallery'),
        'not_found' => __('No Gallery Item Found', 'image-gallery'),
        'not_found_in_trash' => __('No Gallery Item found in Trash', 'image-gallery'),
    );

    $args = array(
        'labels' => $labels,
        'has_archive' => true,
        'public' => true,
        'publicly_queryable' => false,
        'hierarchical' => false,
        'supports' => array(
            'title',
            'editor',
            'author',
            'custom-fields',
            'thumbnail',
            'page-attributes'
        ),
        'rewrite' => array('slug' => 'image-gallery'),
        'show_in_rest' => false
    );
    register_post_type('image-gallery', $args);
}
add_action('init', 'gallery_post_type_add');



// Gallery custom taxonomy creation
add_action('init', 'cps_gallery_taxonomy', 0);
function cps_gallery_taxonomy()
{
    $labels = array(
        'name' => _x('Categories', 'taxonomy general name'),
        'singular_name' => _x('Category', 'taxonomy singular name'),
        'search_items' => __('Search Categories'),
        'all_items' => __('All Categories'),
        'parent_item' => __('Parent Category'),
        'parent_item_colon' => __('Parent Category:'),
        'edit_item' => __('Edit Category'),
        'update_item' => __('Update Category'),
        'add_new_item' => __('Add New Category'),
        'new_item_name' => __('New Category Name'),
        'menu_name' => __('Categories'),
    );
    register_taxonomy(
        'cps_gallery_category',
        array('image-gallery'),
        array(
            'hierarchical' => true,
            'labels' => $labels,
            'public' => true,
            'publicly_queryable' => false,
            'show_ui' => true,
            'show_admin_column' => true,
            'show_in_rest' => false,
            'query_var' => true,
            'rewrite' => array('slug' => 'cps_gallery_category'),
        )
    );
}


// Add a meta box for the redirect URL
function add_redirect_url_meta_box() {
    add_meta_box(
        'redirect_url_meta_box', // Unique ID
        'Redirect URL', // Box title
        'redirect_url_meta_box_html', // Content callback, must be of type callable
        'image-gallery', // Post type
        'side', // Context
        'default' // Priority
    );
}
add_action('add_meta_boxes', 'add_redirect_url_meta_box');

// Meta box HTML
function redirect_url_meta_box_html($post) {
    $value = get_post_meta($post->ID, '_redirect_url', true);
    ?>
    <label for="redirect_url_field">Redirect URL</label>
    <input type="text" name="redirect_url_field" id="redirect_url_field" value="<?php echo esc_attr($value); ?>" size="25" />
    <?php
}

// Save the meta box data
function save_redirect_url_meta_box_data($post_id) {
    if (array_key_exists('redirect_url_field', $_POST)) {
        update_post_meta(
            $post_id,
            '_redirect_url',
            sanitize_text_field($_POST['redirect_url_field'])
        );
    }
}
add_action('save_post', 'save_redirect_url_meta_box_data');
