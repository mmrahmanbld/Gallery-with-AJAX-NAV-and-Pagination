<?php get_header(); ?>

<main id="main-content" class="site-main">
    <div class="container">
        
        <!-- Archive Title (OUTSIDE the Grid) -->
        <?php if (is_category()) { ?>
            <h1 class="archive-title h2"><?php single_cat_title(); ?></h1>
        <?php } elseif (is_tag()) { ?>
            <h1 class="archive-title h2"><?php _e('Posts Tagged:', 'porfyritheme'); ?> <?php single_tag_title(); ?></h1>
        <?php } elseif (is_author()) {
            global $post;
            $author_id = $post->post_author; ?>
            <h1 class="archive-title h2"><?php _e('Posts By:', 'porfyritheme'); ?> <?php the_author_meta('display_name', $author_id); ?></h1>
        <?php } elseif (is_day()) { ?>
            <h1 class="archive-title h2"><?php _e('Daily Archives:', 'porfyritheme'); ?> <?php the_time('l, F j, Y'); ?></h1>
        <?php } elseif (is_month()) { ?>
            <h1 class="archive-title h2"><?php _e('Monthly Archives:', 'porfyritheme'); ?> <?php the_time('F Y'); ?></h1>
        <?php } elseif (is_year()) { ?>
            <h1 class="archive-title h2"><?php _e('Yearly Archives:', 'porfyritheme'); ?> <?php the_time('Y'); ?></h1>
        <?php } ?>

        <!-- Blog Post Grid Layout -->
        <div class="row">
            <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                <div class="blog-container">
                    <a href="<?php the_permalink(); ?>">
                        <?php if (has_post_thumbnail()) { 
                            echo get_the_post_thumbnail($post->ID, 'porfyri-blog', ['class' => 'custom-archive-thumbnail']);
                        } else { 
                            $fallback_image = catch_that_image();
                            if ($fallback_image) {
                                echo '<img src="' . esc_url($fallback_image) . '" class="custom-archive-thumbnail" alt="' . get_the_title() . '">';
                            }
                        } ?>
                    </a>

                    <article id="post-<?php the_ID(); ?>" <?php post_class('cf'); ?> role="article">
                        <header class="entry-header">
                            <h2 class="entry-title">
                                <a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
                            </h2>
                        </header>
                    </article>
                </div>
            <?php endwhile; ?>
        </div> <!-- End .row -->

        <!-- Pagination (OUTSIDE the Grid) -->
        <?php if (is_category()) : ?>
            <div class="category-pagination-wrapper">
                <?php custom_category_pagination(); ?>
            </div>
        <?php endif; ?>


        <?php else : ?>
            <article id="post-not-found" class="hentry cf">
                <header class="article-header">
                    <h1><?php _e('Oops, Post Not Found!', 'porfyritheme'); ?></h1>
                </header>
                <section class="entry-content">
                    <p><?php _e('Uh Oh. Something is missing. Try double-checking things.', 'porfyritheme'); ?></p>
                </section>
            </article>
        <?php endif; ?>

    </div> <!-- End .container -->
</main>

<?php get_footer(); ?>
