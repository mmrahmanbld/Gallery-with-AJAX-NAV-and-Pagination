jQuery(document).ready(function($) {
    var current_page = 1;
    var posts_per_page = 21;

    function loadGalleryItems(category_id, paged) {
        var data = {
            action: 'cps_gallery_filter',
            category_id: category_id,
            paged: paged,
            posts_per_page: 21
        };
    
        $.ajax({
            url: cps_gallery_ajax.ajax_url,
            type: 'POST',
            data: data,
            beforeSend: function() {
                $('.filter-gallery-item-container').append('<div class="loading"></div>');
            },
            success: function(response) {
                $('#gallery-container').html(response);
                lightbox.init();

                $('.loading').remove();
            }
        });
    }
    

    // Event handler for category filter
    $(document).on('click', '.filter-gallery-nav ul li', function(e) {
        $(".filter-gallery-nav ul li").removeClass("nav-active");
        $(this).addClass("nav-active");

        var category_id = $(this).data('gallery-cat-id');
        current_page = 1; // Reset to the first page on category change
        loadGalleryItems(category_id, current_page);
    });

    // Event handler for pagination
    $(document).on('click', '.pagination a', function(e) {
        e.preventDefault();
        var category_id = $(".filter-gallery-nav ul li.nav-active").data('gallery-cat-id');
        var paged = $(this).attr('href').split('paged=')[1];
        current_page = parseInt(paged);
        loadGalleryItems(category_id, current_page);
    });

    // Special handling for category ID 11 to redirect instead of lightbox
    $(document).on('click', '.gallery-item.cat-11 .gallery-link', function(e) {
        e.preventDefault();
        var redirectUrl = $(this).attr('href');
        window.open(redirectUrl, '_blank');
    });

    // Disable scrolling when the lightbox is opened and enable it when closed
    $(document).on('lightbox:open', function() {
        $('body').addClass('no-scroll');
    });

    // Ensure lightbox triggers the events
    lightbox.option({
        'alwaysShowNavOnTouchDevices': true,
        'disableScrolling': true,
    });

    // New functionality: Check URL for category parameter on page load
    function getUrlParameter(name) {
        name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
        var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
        var results = regex.exec(location.search);
        return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
    }

    var categoryFromUrl = getUrlParameter('category');
    if (categoryFromUrl) {
        var category_id = parseInt(categoryFromUrl);
        if (category_id > 0) {
            // Update the navigation to reflect the selected category
            $(".filter-gallery-nav ul li").removeClass("nav-active");
            $(".filter-gallery-nav ul li[data-gallery-cat-id='" + category_id + "']").addClass("nav-active");

            // Load the gallery items for the specified category
            current_page = 1;
            loadGalleryItems(category_id, current_page);
        }
    }
});


