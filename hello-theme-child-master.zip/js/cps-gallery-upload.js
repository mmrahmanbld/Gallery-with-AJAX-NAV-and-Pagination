jQuery(document).ready(function($) {
    $('#bulk-upload-btn').click(function(e) {
        e.preventDefault();
        
        var category_id = $('#gallery_category').val();
        if (!category_id) {
            alert('Please select a category first.');
            return;
        }

        var frame = wp.media({
            title: 'Upload Images',
            multiple: true,
            library: { type: 'image' },
            button: { text: 'Use these images' }
        });

        frame.on('select', function() {
            var attachments = frame.state().get('selection').toJSON();
            var image_ids = [];

            attachments.forEach(function(attachment) {
                image_ids.push(attachment.id);
                $('#uploaded-images-preview').append('<img src="' + attachment.url + '" style="max-width:300px; margin:5px;">');
            });

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'cps_bulk_upload_gallery',
                    image_ids: image_ids,
                    category_id: category_id
                },
                success: function(response) {
                    alert(response);
                }
            });
        });

        frame.open();
    });
});
